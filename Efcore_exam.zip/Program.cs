using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using EfcoreExam.Data;
using EfcoreExam.Models;

namespace EfcoreExam
{
    class Program
    {
        static void Main()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=EfcoreExamDb;Trusted_Connection=True;")
                .Options;

            using (var ctx = new AppDbContext(options))
            {
                ctx.Database.EnsureDeleted();
                ctx.Database.EnsureCreated();

                var m = new Musician
                {
                    FirstName = "Amr",
                    LastName = "Ali",
                    PhoneNumber = "+201234567890",
                    Email = "amr.ali@example.com",
                    Password = "Secret123",
                    City = "Cairo",
                    Country = "Egypt"
                };
                ctx.Musicians.Add(m);
                ctx.SaveChanges();
                Console.WriteLine("Record Added");

                var read = ctx.Musicians.Where(x => x.MusId == m.MusId).FirstOrDefault();
                if (read != null)
                {
                    Console.WriteLine($"Read Musician: {read.MusId} - {read.FirstName} {read.LastName} - {read.Email}");
                }

                read.City = "Alexandria";
                read.PhoneNumber = "+201112223344";
                ctx.Musicians.Update(read);
                ctx.SaveChanges();
                Console.WriteLine("Record Updated");

                ctx.Musicians.Remove(read);
                ctx.SaveChanges();
                Console.WriteLine("Record Removed");
            }
        }
    }
}
