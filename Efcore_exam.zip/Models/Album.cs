using System;
namespace EfcoreExam.Models
{
    public class Album
    {
        public int AlbumIdentifier { get; set; }

        public string? Title { get; set; }

        public DateTime CopyrightDate { get; set; }

        public decimal Price { get; set; }

        public TimeSpan? Duration { get; set; }
    }
}
