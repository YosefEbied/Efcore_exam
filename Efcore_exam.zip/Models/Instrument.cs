using System.ComponentModel.DataAnnotations;

namespace EfcoreExam.Models
{
    public class Instrument
    {
        [StringLength(20)]
        public string Name { get; set; }

        [StringLength(10)]
        public string? MusicalKey { get; set; }
    }
}
