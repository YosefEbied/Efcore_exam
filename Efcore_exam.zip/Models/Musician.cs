using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EfcoreExam.Models
{
    public class Musician
    {
        public int MusId { get; set; }

        [Required]
        [StringLength(20)]
        public string FirstName { get; set; }

        [StringLength(20)]
        public string? LastName { get; set; }

        [NotMapped]
        public string FullName => (FirstName + " " + (LastName ?? "")).Trim();

        [Phone]
        public string? PhoneNumber { get; set; }

        [EmailAddress]
        public string? Email { get; set; }

        public string? Password { get; set; }

        [StringLength(20, MinimumLength = 5)]
        public string? City { get; set; }

        [StringLength(20, MinimumLength = 5)]
        public string? Country { get; set; }

        [NotMapped]
        public string DisplayPassword => string.IsNullOrEmpty(Password) ? string.Empty : new string('*', 5);
    }
}
