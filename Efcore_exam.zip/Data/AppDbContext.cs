using Microsoft.EntityFrameworkCore;
using EfcoreExam.Models;

namespace EfcoreExam.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Musician> Musicians { get; set; }
        public DbSet<Instrument> Instruments { get; set; }
        public DbSet<Album> Albums { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Musician>(b =>
            {
                b.HasKey(m => m.MusId);
                b.Property(m => m.MusId).UseIdentityColumn(10, 10);
                b.Property(m => m.FirstName).IsRequired().HasMaxLength(20);
                b.Property(m => m.LastName).HasMaxLength(20).IsRequired(false);
                b.Property(m => m.PhoneNumber);
                b.Property(m => m.Email);
                b.Property(m => m.Password);
                b.Property(m => m.City).HasMaxLength(20);
                b.Property(m => m.Country).HasMaxLength(20);
                b.Ignore(m => m.FullName);
            });

            modelBuilder.Entity<Instrument>(b =>
            {
                b.HasKey(i => i.Name);
                b.Property(i => i.Name).HasMaxLength(20);
                b.Property(i => i.MusicalKey).HasMaxLength(10).HasDefaultValue("B-flat");
                b.Property<int>("Code").HasColumnName("Code");
                b.HasCheckConstraint("CK_Instrument_Code_Range", "[Code] >= 1 AND [Code] <= 100");
            });

            modelBuilder.Entity<Album>(b =>
            {
                b.ToTable("AlbumData");
                b.HasKey(a => a.AlbumIdentifier);
                b.Property(a => a.Title).HasMaxLength(20).IsRequired(false);
                b.Property(a => a.CopyrightDate)
                    .HasDefaultValueSql("GETDATE()");
                b.Property(a => a.Price).HasColumnType("decimal(8,2)");
                b.Ignore(a => a.Duration);
            });
        }
    }
}
